Telegram bot like t.me/paynet_uzbekbot for promoting any channel. Users subscribe to your channel, invite their friends and promote it themself and you pay them little for that.

You must credit this repo if you use code by leaving link https://github.com/Khuzha/refbot or link t.me/Khuzha
