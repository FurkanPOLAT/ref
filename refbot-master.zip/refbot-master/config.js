module.exports = {
  text: {
    hello: 'It`s greeting text. Here is user`s referal link: t.me/RefOneBot?start=', // then index.js adds here user`s id
    invite: 'It`s text, which shows when user share link. Here is also user`s referal link: t.me/RefOneBot?start='
  }

  // any other configs you need
}